const AWS = require('aws-sdk');
exports.handler = async (event, context) => {

  const queueUrl = process.env.QUEUE_URL;
  const functionName=process.env.EVAL_FUNCTION;
  const tableName=process.env.ASSETS_TABLE

  const sqs = new AWS.SQS();
  const lambda = new AWS.Lambda();
  const dynamoDB = new AWS.DynamoDB.DocumentClient();


  const params = {
    QueueUrl: queueUrl
  };

  try {
    const response = await sqs.receiveMessage(params).promise();

    if (response.Messages) {
      for (const message of response.Messages) {

        const assetEvaluationParams = {
          FunctionName: functionName,
          InvocationType: 'RequestResponse',
          Payload: JSON.stringify({ body: message.Body }) 
        };

        const response = await lambda.invoke(assetEvaluationParams).promise();

        const responseBody = JSON.parse(response.Payload);
 
        responseBody['id'] = `${Math.random()}`;

        console.log('Response from second Lambda:', responseBody);

        const dynamoDBParams = {
          TableName: tableName,
          Item: responseBody
        };

        await dynamoDB.put(dynamoDBParams).promise();

        await sqs.deleteMessage({
          QueueUrl: queueUrl,
          ReceiptHandle: message.ReceiptHandle
        }).promise();
      }
    }
  } catch (error) {
    console.error('Error receiving messages:', error);
  }
};

