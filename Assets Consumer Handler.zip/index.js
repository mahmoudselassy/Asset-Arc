const AWS = require('aws-sdk');
const sqs = new AWS.SQS();
const lambda = new AWS.Lambda();
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  const queueUrl = process.env.QUEUE_URL;
  const functionName = process.env.EVAL_FUNCTION;
  const tableName = process.env.ASSETS_TABLE;

 try {
    for (const record of event.Records) {
      const message = record.body;
      const assetEvaluationParams = {
        FunctionName: functionName,
        InvocationType: 'RequestResponse',
        Payload: JSON.stringify({ body: message }) 
      };

      const response = await lambda.invoke(assetEvaluationParams).promise();
      
      console.log(response);
 
      const responseBody = JSON.parse(response.Payload);

      
      // Store the message in DynamoDB
      const params = {
        TableName: tableName,
        Item: {
          id: record.messageId,
          ...responseBody
        }
      };
      
      await dynamoDB.put(params).promise();

      // Delete the message from the SQS queue
      const deleteParams = {
        QueueUrl: queueUrl,
        ReceiptHandle: record.receiptHandle
      };
      
      await sqs.deleteMessage(deleteParams).promise();
    }

    return {
      statusCode: 200,
      body: 'Message processing complete'
    };
  } catch (error) {
    console.error(error);
    throw error;
  }
};
