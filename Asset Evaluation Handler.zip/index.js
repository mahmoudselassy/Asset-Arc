exports.handler = async (event) => {
  try {
    const message = JSON.parse(event.body);
    const url = `${process.env.CHATGPT_URL}`;
    const options = {
          method: "post",
          headers: { Authorization: `Bearer ${process.env.CHATGPT_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({ model: "gpt-3.5-turbo", messages: [{ role: "user", content: message }] }),
    };
    const response = await fetch(url, options);
    const data = await response.json();
    const res = {
      statusCode: 200,
      body: JSON.stringify({ message: 'Successfully processed message', body: data.choices[0].message.content })
    };

    console.log(res);

    return res;
  } catch (error) {
    console.error('Error processing message:', error);
    const res = {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error processing message' })
    };
    return res;
  }
};
