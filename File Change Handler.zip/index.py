import boto3
import csv
import json

s3 = boto3.client('s3')
sqs = boto3.client('sqs')

def handler(event, context):
    # Retrieve the bucket and key information from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Download the CSV file from S3
    response = s3.get_object(Bucket=bucket, Key=key)
    
    # Read the CSV file using csv module
    csv_file = response['Body'].read().decode('utf-8').splitlines()
    reader = csv.DictReader(csv_file)
    
    # Create a list to store the rows
    rows_list = []
    
    # Iterate over each row and append it to the list
    for row in reader:
        rows_list.append(row)
    
    # Retrieve the SQS queue URL dynamically
    queue_name = 'assets-queue'  # Replace with your SQS queue name
    response = sqs.get_queue_url(QueueName=queue_name)
    queue_url = response['QueueUrl']
    print(len(rows_list))
    # Send each element of the list to SQS
    for row in rows_list:
        # Push the row dictionary to SQS
        json_body = json.dumps(row)
        
        print(row)  
        
        sqs.send_message(QueueUrl=queue_url, MessageBody=json_body)
    
    return {
        'statusCode': 200,
        'body': 'CSV processing complete'
    }
