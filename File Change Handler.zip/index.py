import csv
import boto3
from io import TextIOWrapper

def handler(event, context):
    # Retrieve the bucket and key information from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Create an S3 client
    s3 = boto3.client('s3')
    
    # Create an SQS client
    sqs = boto3.client('sqs')
    
    # Download the CSV file from S3
    response = s3.get_object(Bucket=bucket, Key=key)
    
    # Process the CSV file in chunks using a streaming iterator
    csv_stream = response['Body']
    text_stream = TextIOWrapper(csv_stream, encoding='utf-8', errors='replace')
    csv_reader = csv.DictReader(text_stream)
    
    # Retrieve the SQS queue URL dynamically
    queue_name = 'assets-queue'  # Replace with your SQS queue name
    response = sqs.get_queue_url(QueueName=queue_name)
    queue_url = response['QueueUrl']
    
    # Push each row to SQS
    for row in csv_reader:
        # Push the row to SQS
        sqs.send_message(QueueUrl=queue_url, MessageBody=str(row))
    
    return {
        'statusCode': 200,
        'body': 'CSV processing complete'
    }
